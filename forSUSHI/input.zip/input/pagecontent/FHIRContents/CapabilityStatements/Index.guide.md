## 2.5. Capability Statements

