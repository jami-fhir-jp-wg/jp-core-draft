## [2.1.3.2 ImagingStudy（画像検査）](ImagingStudy2)

