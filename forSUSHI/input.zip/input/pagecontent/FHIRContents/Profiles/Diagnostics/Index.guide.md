## 2.1.3. Diagnostics（診断）プロファイル
{{index:current}}